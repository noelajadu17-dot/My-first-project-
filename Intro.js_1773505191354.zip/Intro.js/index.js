// intro.js
const name = "Noel Gabriel";
const age = 22; 
const favoriteLanguage = "JavaScript";

console.log("Name:", name);
console.log("Age:", age);
console.log("Favorite Programming Language:", favoriteLanguage);
